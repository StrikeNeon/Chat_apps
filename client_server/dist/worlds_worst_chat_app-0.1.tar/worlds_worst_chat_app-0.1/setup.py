from setuptools import setup

setup(
  name='worlds_worst_chat_app',
  version = "0.1",
  description = "Worst python socket based client-server chat, that stretches the defenition of functional",
  author = "TF",
  author_email = "SjasFaceMD@gmail.com",
  url = "https://github.com/StrikeNeon/Chat_apps",
  packages=["src"]
)
